## Red Hat Mobile Application Platform Reference Architecture 
 
 - Ionic client e-commerce example application 
